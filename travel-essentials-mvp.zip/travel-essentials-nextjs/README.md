# Travel Essentials — AI Curator (MVP)

Next.js App Router (JavaScript), no external UI libs.

## Run locally
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy on Vercel
- Push this folder to GitHub.
- Import the repo on https://vercel.com/new
- Framework detected: Next.js → Deploy.
