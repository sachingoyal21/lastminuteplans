// ================================================
// AI Travel Essentials — Working Prototype (React)
// Option B: Next.js + Vercel friendly (no external UI deps)
// ================================================

"use client";
import React, { useEffect, useMemo, useState } from "react";

// ------------------------
// Minimal toast shim (console based)
// ------------------------
const toast = {
  success: (msg) => console.log(`✅ ${msg}`),
  error: (msg) => console.error(`⛔ ${msg}`),
};

// ------------------------
// Helper utilities
// ------------------------
const monthFromISO = (iso) => {
  if (!iso) return null;
  try { return new Date(iso).getMonth() + 1; } catch { return null; }
};

const nightsBetween = (start, end) => {
  if (!start || !end) return 2; // default weekend length when missing inputs
  const s = new Date(start);
  const e = new Date(end);
  const ms = Math.max(0, e - s);
  // same‑day -> 0 nights (per user preference)
  return Math.max(0, Math.round(ms / (1000 * 60 * 60 * 24)));
};

const encode = encodeURIComponent;
const amazonUrl = (q) => `https://www.amazon.in/s?k=${encode(q)}`;
const flipkartUrl = (q) => `https://www.flipkart.com/search?q=${encode(q)}`;

// Destination → climate hints (heuristic; no network)
function inferRegion(destination = "") {
  const d = destination.toLowerCase();
  const has = (arr) => arr.some((x) => d.includes(x));
  if (has(["manali","shimla","leh","ladakh","srinagar","gulmarg","nainital","mussoorie","darjeeling","gangtok","ooty"])) return "mountains";
  if (has(["goa","mumbai","gokarna","andaman","pondicherry","kochi","alleppey","varkala"])) return "coastal";
  if (has(["jaipur","jaisalmer","jodhpur","udaipur","ahmedabad"])) return "desert";
  if (has(["delhi","gurugram","noida"])) return "north_plains";
  if (has(["bengaluru","bangalore","mysore","coorg"])) return "deccan";
  return "general";
}

function inferWeatherBand({ destination, startDate }) {
  const m = monthFromISO(startDate) || 6; // default June
  const region = inferRegion(destination);
  if (region === "mountains") {
    if ([11,12,1,2].includes(m)) return { band: "cold", note: "Mountain winter likely cold" };
    if ([6,7,8,9].includes(m)) return { band: "rainy", note: "Monsoon in hill regions" };
    return { band: "cool", note: "Pleasant but can be chilly" };
  }
  if (region === "coastal") {
    if ([6,7,8,9].includes(m)) return { band: "rainy", note: "Coastal monsoon" };
    return { band: "hot", note: "Humid & warm" };
  }
  if (region === "desert") {
    if ([4,5,6].includes(m)) return { band: "very_hot", note: "Hot summer" };
    if ([12,1,2].includes(m)) return { band: "cool", note: "Dry & cool nights" };
    return { band: "hot", note: "Warm to hot" };
  }
  if (region === "north_plains") {
    if ([12,1,2].includes(m)) return { band: "cold", note: "North winter" };
    if ([5,6].includes(m)) return { band: "very_hot", note: "Peak summer" };
    if ([7,8,9].includes(m)) return { band: "rainy", note: "Monsoon" };
    return { band: "mild", note: "Pleasant" };
  }
  if (region === "deccan") {
    if ([6,7,8,9].includes(m)) return { band: "rainy", note: "Intermittent rain" };
    return { band: "mild", note: "Generally mild" };
  }
  return { band: "mild", note: "Estimated" };
}

// Items knowledge base
function baseEssentials() {
  return [
    { name: "Phone charger", category: "Electronics", reason: "Daily power" },
    { name: "Power bank 10000mAh", category: "Electronics", reason: "On-the-go charging" },
    { name: "Universal travel adapter", category: "Electronics", reason: "Sockets vary" },
    { name: "Earphones / headphones", category: "Electronics" },
    { name: "Wallet, ID, Aadhaar", category: "Documents" },
    { name: "Cash + UPI ready", category: "Money" },
    { name: "Water bottle (leak-proof)", category: "Comfort" },
    { name: "Toiletry kit (toothbrush, mini toothpaste, soap, shampoo)", category: "Toiletries" },
    { name: "Sunscreen SPF 50", category: "Health" },
    { name: "Lip balm", category: "Health" },
    { name: "Hand sanitiser", category: "Health" },
    { name: "Basic meds (paracetamol, ORS)", category: "Health" },
    { name: "Band-aids", category: "Health" },
    { name: "Sunglasses", category: "Clothing" },
    { name: "Tissues / wet wipes", category: "Comfort" },
    { name: "Small backpack / daypack", category: "Bags" },
  ];
}

function clothingByNights(nights, band, purpose) {
  const arr = [];
  // Same-day: skip base clothing counts (per user preference)
  if (nights > 0) {
    const tees = Math.min(7, nights + 1);
    const underwear = Math.min(10, nights + 2);
    const socks = Math.min(10, nights + 1);
    arr.push(
      { name: `${tees} x breathable T‑shirts`, category: "Clothing" },
      { name: `${Math.ceil(nights/2)} x bottoms (jeans/shorts)`, category: "Clothing" },
      { name: `${underwear} x underwear`, category: "Clothing" },
      { name: `${socks} x socks`, category: "Clothing" },
    );
  }
  if (["cold","cool"].includes(band)) arr.push({ name: "Warm jacket / fleece", category: "Clothing", reason: "Chilly weather" });
  if (["very_hot","hot"].includes(band)) arr.push({ name: "Light cottons / linen", category: "Clothing" });
  if (band === "rainy") arr.push({ name: "Quick‑dry clothing", category: "Clothing" });
  if (purpose === "beach") arr.push({ name: "Swimwear", category: "Clothing" });
  if (purpose === "business") arr.push({ name: "1 x formal outfit", category: "Clothing" });
  return arr;
}

function weatherExtras(band, region) {
  const arr = [];
  if (band === "rainy") arr.push(
    { name: "Umbrella", category: "Weather" },
    { name: "Raincoat", category: "Weather" },
    { name: "Waterproof phone pouch", category: "Weather" },
    { name: "Mosquito repellent", category: "Health" },
  );
  if (band === "cold") arr.push(
    { name: "Thermals", category: "Weather" },
    { name: "Beanie + gloves", category: "Weather" },
    { name: "Moisturiser", category: "Health" },
  );
  if (band === "cool") arr.push({ name: "Light sweater", category: "Weather" });
  if (band === "very_hot" || band === "hot") arr.push(
    { name: "Electrolyte sachets", category: "Health" },
    { name: "Cap / hat", category: "Clothing" },
  );
  if (region === "mountains") arr.push({ name: "Trekking shoes (grip)", category: "Footwear" });
  if (region === "coastal") arr.push({ name: "Flip‑flops / sandals", category: "Footwear" });
  return arr;
}

function modeExtras(mode) {
  switch (mode) {
    case "bike":
      return [
        { name: "IS‑certified helmet", category: "Bike" },
        { name: "Riding gloves", category: "Bike" },
        { name: "Rain cover for backpack", category: "Bike" },
        { name: "Bungee cords / cargo net", category: "Bike" },
        { name: "Puncture kit + mini inflator", category: "Bike" },
        { name: "Chain lube", category: "Bike" },
        { name: "Reflective vest", category: "Bike" },
      ];
    case "car":
      return [
        { name: "Dual USB car charger", category: "Car" },
        { name: "Neck pillow", category: "Comfort" },
        { name: "Windshield sunshade", category: "Car" },
      ];
    case "flight":
      return [
        { name: "Neck pillow / eye mask", category: "Comfort" },
        { name: "TSA‑friendly bottles", category: "Bags" },
        { name: "Document organiser", category: "Documents" },
      ];
    case "train":
      return [
        { name: "Earplugs", category: "Comfort" },
        { name: "Small lock for luggage", category: "Security" },
      ];
    default:
      return [];
  }
}

function purposeExtras(purpose) {
  switch (purpose) {
    case "beach":
      return [ { name: "Beach towel (quick‑dry)", category: "Bags" }, { name: "Aloe vera gel", category: "Health" } ];
    case "trekking":
      return [ { name: "Daypack 20‑30L", category: "Bags" }, { name: "Reusable snack bags", category: "Food" }, { name: "Headlamp", category: "Electronics" } ];
    case "business":
      return [ { name: "Laptop + charger", category: "Electronics" }, { name: "Notebook + pen", category: "Stationery" } ];
    default:
      return [];
  }
}

function dedupe(items) {
  const seen = new Set();
  return items.filter((it) => {
    const key = (it.name || '').toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function buildChecklist(ctx) {
  const { destination, startDate, endDate, mode, purpose, weatherOverride } = ctx;
  const nights = nightsBetween(startDate, endDate);
  const region = inferRegion(destination);
  const inferred = inferWeatherBand({ destination, startDate });
  const band = weatherOverride && weatherOverride !== "" ? weatherOverride : inferred.band;
  const items = [
    ...baseEssentials(),
    ...clothingByNights(nights, band, purpose),
    ...weatherExtras(band, region),
    ...modeExtras(mode),
    ...purposeExtras(purpose),
    { name: "Tickets / bookings (PDF & offline)", category: "Documents" },
    (mode === "bike" || mode === "car") ? { name: "Driving licence & RC/PUC", category: "Documents" } : null,
  ].filter(Boolean);
  return dedupe(items);
}

function productLinksFor(itemName) {
  return [
    { vendor: "Amazon", url: amazonUrl(itemName) },
    { vendor: "Flipkart", url: flipkartUrl(itemName) },
  ];
}

// ------------------------
// Component
// ------------------------
export default function Travel() {
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [mode, setMode] = useState("flight");
  const [purpose, setPurpose] = useState("leisure");
  const [weatherOverride, setWeatherOverride] = useState("auto"); // non-empty to avoid Select empty
  const [customItem, setCustomItem] = useState("");
  const [checked, setChecked] = useState({});
  const [list, setList] = useState([]);

  const nights = useMemo(() => nightsBetween(startDate, endDate), [startDate, endDate]);
  const inferred = useMemo(() => inferWeatherBand({ destination, startDate }), [destination, startDate]);

  useEffect(() => {
    // Auto-generate when inputs are filled
    if (destination && startDate && endDate && mode) {
      const next = buildChecklist({ destination, startDate, endDate, mode, purpose, weatherOverride: weatherOverride === "auto" ? "" : weatherOverride });
      setList(next);
      setChecked({});
    }
  }, [destination, startDate, endDate, mode, purpose, weatherOverride]);

  const checkedCount = Object.values(checked).filter(Boolean).length;

  const addCustom = () => {
    if (!customItem.trim()) return;
    setList((x) => dedupe([...x, { name: customItem.trim(), category: "Custom" }]));
    setCustomItem("");
    toast.success("Added to checklist");
  };

  const downloadList = () => {
    const lines = list.map((it) => `- [${checked[it.name] ? "x" : " "}] ${it.name} (${it.category})`).join("\n");
    const blob = new Blob([lines], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `travel-checklist-${Date.now()}.txt`; a.click();
    URL.revokeObjectURL(url);
  };

  const copyList = async () => {
    const lines = list.map((it) => `• ${it.name}`).join("\n");
    await navigator.clipboard.writeText(lines);
    toast.success("Checklist copied to clipboard");
  };

  const shareLink = async () => {
    const payload = encodeURIComponent(JSON.stringify({ destination, startDate, endDate, mode, purpose, weatherOverride }));
    const url = `${location.origin}${location.pathname}#${payload}`;
    await navigator.clipboard.writeText(url);
    toast.success("Sharable link copied");
  };

  useEffect(() => {
    // Read from URL hash for share
    if (typeof location !== "undefined" && location.hash.length > 2) {
      try {
        const payload = JSON.parse(decodeURIComponent(location.hash.slice(1)));
        setDestination(payload.destination || "");
        setStartDate(payload.startDate || "");
        setEndDate(payload.endDate || "");
        setMode(payload.mode || "flight");
        setPurpose(payload.purpose || "leisure");
        setWeatherOverride(payload.weatherOverride && payload.weatherOverride !== "" ? payload.weatherOverride : "auto");
      } catch {}
    }
  }, []);

  // ------------------------
  // Smoke tests (added)
  // ------------------------
  useEffect(() => { try { runSmokeTests(); } catch (e) { console.error("Tests failed:", e); } }, []);

  // ------------------------
  // Styles (inline for simplicity)
  // ------------------------
  const wrap = { maxWidth: 1040, margin: "0 auto", padding: 16, fontFamily: "Inter, system-ui, Arial, sans-serif" };
  const card = { border: "1px solid #e5e7eb", borderRadius: 16, padding: 16, background: "#fff" };
  const header = { position: "sticky", top: 0, background: "rgba(255,255,255,0.8)", backdropFilter: "saturate(180%) blur(10px)", borderBottom: "1px solid #e5e7eb", padding: "8px 16px", zIndex: 10 };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(#f8fafc, #fff)", color: "#0f172a" }}>
      <header style={header}>
        <div style={{ maxWidth: 1040, margin: "0 auto", display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 20 }}>🎒</span>
          <strong>Travel Essentials — AI Curator</strong>
          <span style={{ marginLeft: "auto", fontSize: 12, padding: "2px 8px", border: "1px solid #e5e7eb", borderRadius: 999 }}>MVP</span>
        </div>
      </header>

      <main style={wrap}>
        <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 16 }}>
          {/* Left: Trip Inputs */}
          <section style={card}>
            <h3 style={{ marginTop: 0, fontSize: 16 }}>Trip Inputs</h3>

            <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>📍 Destination</label>
            <input placeholder="e.g., Manali, Goa" value={destination} onChange={(e) => setDestination(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #e5e7eb", marginBottom: 12 }} />

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>📅 Start</label>
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #e5e7eb" }} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>End</label>
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #e5e7eb" }} />
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>Mode</label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6 }}>
                {["flight","train","car","bike"].map((m) => (
                  <button key={m} onClick={() => setMode(m)} style={{ padding: 8, borderRadius: 10, border: "1px solid #e5e7eb", background: mode === m ? "#eef2ff" : "#fff", fontWeight: mode === m ? 600 : 500 }}>
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>Purpose</label>
              <select value={purpose} onChange={(e) => setPurpose(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #e5e7eb" }}>
                <option value="leisure">Leisure</option>
                <option value="beach">Beach</option>
                <option value="trekking">Trekking</option>
                <option value="business">Business</option>
              </select>
            </div>

            <div style={{ marginTop: 12 }}>
              <label style={{ display: "block", fontSize: 12, marginBottom: 4 }}>Weather (auto: {inferred.band})</label>
              <select value={weatherOverride} onChange={(e) => setWeatherOverride(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #e5e7eb" }}>
                <option value="auto">Auto (recommended)</option>
                <option value="very_hot">Very hot</option>
                <option value="hot">Hot</option>
                <option value="mild">Mild</option>
                <option value="cool">Cool</option>
                <option value="cold">Cold</option>
                <option value="rainy">Rainy</option>
              </select>
              <p style={{ fontSize: 12, color: "#64748b" }}>{inferred.note}</p>
            </div>

            <button onClick={() => {
              if (!destination || !startDate || !endDate) {
                toast.error("Please fill destination & dates");
                return;
              }
              const next = buildChecklist({ destination, startDate, endDate, mode, purpose, weatherOverride: weatherOverride === "auto" ? "" : weatherOverride });
              setList(next);
              setChecked({});
              toast.success("Checklist generated");
            }} style={{ marginTop: 12, width: "100%", padding: 10, borderRadius: 10, border: "1px solid #4338ca", background: "#4f46e5", color: "#fff", fontWeight: 600 }}>
              Get my checklist
            </button>
          </section>

          {/* Right: Result List */}
          <section style={card}>
            <h3 style={{ marginTop: 0, fontSize: 16, display: "flex", gap: 8, alignItems: "center" }}>
              ✨ Your curated list
              <span style={{ marginLeft: 8, fontSize: 12, padding: "2px 8px", border: "1px solid #e5e7eb", borderRadius: 999 }}>{checkedCount}/{list.length} packed</span>
              <span style={{ marginLeft: "auto", fontSize: 12, color: "#64748b" }}>{nights} night(s)</span>
            </h3>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={copyList} style={{ padding: "6px 10px", borderRadius: 10, border: "1px solid #e5e7eb", background: "#fff" }}>📤 Copy</button>
              <button onClick={downloadList} style={{ padding: "6px 10px", borderRadius: 10, border: "1px solid #e5e7eb", background: "#fff" }}>⬇️ Download</button>
              <button onClick={shareLink} style={{ padding: "6px 10px", borderRadius: 10, border: "1px solid #e5e7eb", background: "#fff" }}>🔗 Share link</button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 12, marginTop: 12 }}>
              {list.map((item) => (
                <div key={item.name} style={{ border: "1px solid #e5e7eb", borderRadius: 16, padding: 12 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                    <input type="checkbox" checked={!!checked[item.name]} onChange={(e) => setChecked((c) => ({ ...c, [item.name]: e.target.checked }))} style={{ marginTop: 4 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
                        <span>{item.name}</span>
                      </div>
                      <div style={{ marginTop: 4, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                        <span style={{ fontSize: 11, border: "1px solid #e5e7eb", borderRadius: 999, padding: "2px 8px" }}>{item.category}</span>
                        {item.reason ? <span style={{ fontSize: 11, color: "#64748b" }}>· {item.reason}</span> : null}
                      </div>
                      <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                        {productLinksFor(item.name).map((p) => (
                          <a key={p.vendor} href={p.url} target="_blank" rel="noreferrer" style={{ fontSize: 12, padding: "6px 10px", border: "1px solid #e5e7eb", borderRadius: 10, textDecoration: "none" }}>
                            Buy on {p.vendor}
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
              <input placeholder="Add a custom item…" value={customItem} onChange={(e) => setCustomItem(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addCustom(); }} style={{ flex: 1, padding: 10, borderRadius: 10, border: "1px solid #e5e7eb" }} />
              <button onClick={addCustom} style={{ padding: "6px 12px", borderRadius: 10, border: "1px solid #e5e7eb", background: "#fff" }}>Add</button>
            </div>

            <div style={{ fontSize: 12, color: "#64748b", marginTop: 8 }}>
              • Counts auto-scale with trip length. Override weather if you know it better.<br />
              • Links go to Amazon/Flipkart search results — switch products as you like.<br />
              • Use the Share link to send your exact inputs to friends.
            </div>
          </section>
        </div>
      </main>

      <footer style={{ padding: "24px 0", textAlign: "center", fontSize: 12, color: "#64748b" }}>
        Built for MVP usability testing · No tracking · Demo only
      </footer>
    </div>
  );
}

// ------------------------
// Smoke tests (added — none existed in this file)
// ------------------------
function runSmokeTests() {
  console.groupCollapsed("Travel Essentials — Smoke Tests");
  console.assert(nightsBetween("2025-08-01", "2025-08-04") === 3, "nightsBetween should be 3");
  console.assert(nightsBetween("2025-08-10", "2025-08-10") === 0, "same day should return 0 nights");
  console.assert(inferRegion("Manali") === "mountains", "Region for Manali should be mountains");
  console.assert(inferRegion("Goa") === "coastal", "Region for Goa should be coastal");
  console.assert(inferWeatherBand({ destination: "Goa", startDate: "2025-07-10" }).band === "rainy", "Goa in July should be rainy");

  const demo = buildChecklist({ destination: "Manali", startDate: "2025-12-10", endDate: "2025-12-14", mode: "bike", purpose: "trekking", weatherOverride: "" });
  console.assert(demo.some((x) => /helmet/i.test(x.name)), "Bike mode should include helmet");

  const dup = dedupe([{ name: "A" }, { name: "a" }, { name: "B" }]);
  console.assert(dup.length === 2, "dedupe should remove case-insensitive duplicates");

  const rainyClothes = clothingByNights(3, "rainy", "leisure");
  console.assert(rainyClothes.some((x) => /quick\-?dry/i.test(x.name)), "rainy band should suggest quick-dry clothing");

  const overrideHot = buildChecklist({ destination: "Manali", startDate: "2025-12-10", endDate: "2025-12-12", mode: "flight", purpose: "leisure", weatherOverride: "hot" });
  console.assert(overrideHot.some((x) => /Light cottons/i.test(x.name)), "override 'hot' should affect clothing suggestions");

  const sameDay = buildChecklist({ destination: "Pune", startDate: "2025-09-01", endDate: "2025-09-01", mode: "car", purpose: "leisure", weatherOverride: "" });
  console.assert(!sameDay.some((x) => /(T‑shirts|underwear|socks|bottoms)/i.test(x.name)), "same-day trips: no base clothing counts");

  console.log("All smoke tests passed ✅");
  console.groupEnd();
}
