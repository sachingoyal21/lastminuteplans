"use client";
import React from "react";
import Travel from "./Travel";
export default function Page(){ return <Travel/> }
